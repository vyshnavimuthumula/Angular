import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'bookFilter'
})
export class BookFilterPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    return value.filter((data)=>data.title.indexOf(args)!==-1);
    
  }

}
