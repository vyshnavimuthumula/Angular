import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Ibook } from './ibook';
@Injectable({
  providedIn: 'root'
})
export class BooklistService {
  constructor(private http:HttpClient) { }
  private _url : string ="./assets/booklist.json";

  getBooks():Observable<Ibook[]>{
    return this.http.get<Ibook[]>(this._url);
  }
 
}
