export class User {
    constructor(
        public id : number,
        public name : String,
        public Salary : number,    
        public Department : String
    ) {}
}
