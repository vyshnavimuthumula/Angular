export interface Ibook {
    "id": number,
    "title": String,
    "year": number,
    "author": String
  }

