import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {
  Id: number;
  Name: String;
  Cost: number;

  constructor() { }

  ngOnInit() {
  }
  addProduct(id:number,name:String,cost:number){
    this.Id=id;
    this.Name=name;
    this.Cost=cost;
    console.log(this.Id,this.Name,this.Cost)
  }
}
